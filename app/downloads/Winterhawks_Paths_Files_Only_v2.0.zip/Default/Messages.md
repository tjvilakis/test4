1 life left:0000:0:.LOW ON LIVES!^M=x^M
You have 1 lives left.

2 lives left:0000:6:.LOW ON LIVES!^M=x^M
You have 2 lives left.

acid hits:0000:0:
Acid burns {target} for {dmg} damage!

acid hits:0000:0:
Acid sears {target} for {dmg} damage!

acid rain:0000:0:
Acid rain pours down upon your foe!

acid rain:0008:0:
You are covered in acid
The acid covering you dries up
Afraid:2002:0:
You are too afraid to do that!

alertness:0000:0:
You feel perceptive
The effects of alertness wear off
angelic halo:0000:0:
A halo appears over your head!
Your halo vanishes
arcane tome incantation:0200:0:
You have memorized an arcane incantation
The arcane incantation slips from memory
area flesh-eater:0000:0:
Your flesh is dissolved, causing {target} {dmg} damage!

arrow trap:0000:0:
An arrow shoots out of the door and strikes {target} for {dmg} damage!

ashwood wand:0000:0:
You feel VERY lucky!
The effects of greater bless wear off.
balanced sight:0000:0:
You have the clarity of an ordered mind.
The clarity has vanished
banish:0004:0:
You are afflicted by teleportation sickness
The teleportation sickness wears off
banshee's wail:0002:0:
You are deathly afraid
You don't feel quite so afraid anymore
barbskin:0000:0:
Iron spikes protrude from your skin!
Your skin returns to normal
barkskin:0000:0:
You feel tough
The effects of barkskin wear off
bee honey:0000:0:
You feel a surge of power run through you
The surge of power fades
bee poison:0004:0:
You feel VERY sick
The effects of the poison wear off
belt of might:0000:0:
You feel strong
Your enhanced strength wears off
birch rod:0080:0:
You are regenerating quickly!
You stop regenerating.
bites:0004:0:
Poison burns through your veins
The effects of the poison wear off
black curse:0001:0:
A black curse is upon you
Your vision returns to normal
black orb:0010:0:
Your legs are petrified
Your legs return to normal
black wind:0000:0:
A black wind sweeps throughout the room!

blackwod forest sounds:0000:0:^M
A sudden burst of wind blows down upon you.

blackwood forest sounds:0000:0:^M
Some great beast howls in the

blackwood forest sounds:0000:0:^M
The trees creak towards you, almost with an awful yearning.

blackwood forest sounds:0000:0:^M
A strange gurgling is heard close by.

blackwood forest sounds:0000:0:^M
The bitter scent of evil is rich in the air.

blackwood forest sounds:0000:0:^M
You hear faint whispering behind you.

blackwood staff:0000:0:
Your blackwood staff sucks the life from {target} for {dmg} damage!

blade trap:0000:0:
A blade sweeps out and slices {target} for {dmg} damage!

bladed sphere:0000:0:
You are surrounded by a sphere of blades!
Your sphere disappears into thin air
bleeding:0008:0:
You are bleeding from an unholy wound
The unholy wound closes up
bless:0000:0:
You feel lucky
The effects of bless wear off
blight:0000:0:
You feel unlucky
The effects of curse wear off
blind:0001:0:
You are blind
You can see again
blinding light:0001:0:
You are struck blind
You can see again
blizzard:0000:0:
A storm of freezing hail smashes your foes for {dmg} damage!

blizzard:0000:0:
A storm of freezing hail smashes {target} for {dmg} damage!

blood ritual:0000:0:
You are affected by a blood ritual
The effects of the blood ritual wear off
blur:0000:0:
You are blurred
The effects of blur wear off
brain eater:1400:0:^M
and a small creature leaps out!

breathes:0001:0:
You are blind
The effects of the mummy's breath wears off
burn hits:0000:0:
{target} are burned for {dmg} damage!

burn hits:0000:0:
{target} is burned for {dmg} damage!

burning:0008:0:
You are on fire
The flames scorching you die down
burning death:0008:0:
You are on fire
The flames enveloping you die down
camouflage:0000:0:
You are covered in magical camouflage!
The magic camouflage fades away!
Cancel FUgram:0000:0:n
Would you like to forward your /P to an FUgram?

cedar rod:0000:0:
You feel fast!
You slow down.
chain:0010:2:
You are caught in a chain!
You get back on your feet.
chant:0000:0:
You feel lucky
The effects of bless wear off
chaos shield:0000:0:
You are surrounded by a chaos shield
The chaos shield fizzles out
chaos storm:0000:0:
A chaotic storm assaults {target} for {dmg} damage!

chaos surge:0000:0:
Chaotic energy surrounds your being!
The chaotic energy fades away
chase (alley):4000:0:go alley
{target} slips into the dangerous black alley.

chase (alley):4000:0:go alley
{target} slips into the dark alley.

chase (black gem):4000:0:touch gem
{target} touches the black gem, and is consumed in a crackling field of

chase (burnt stump):4000:0:go stump
{target} climbs through the hole in the burnt stump.

chase (bushes):4000:0:enter bushes
{target} pushes through the bushes!

chase (bushes):4000:0:enter bush
{target} squeezes into the opening under the bushes.

chase (climb):4000:0:climb vines
{target} grasps onto some of the vines, and begins to climb!

chase (crack):4000:0:go crack
{target} walks into the wide crack.

chase (darkwood ring):4000:0:go arch
{target} rubs a darkwood ring, and is swept through the arch!

chase (down):4000:0:d
{target} climbs down to a lower ledge with the aid of a climbing harness.

chase (down):4000:0:d
{target} descends the steps encircling the ancient silverwood tree.

chase (down):4000:0:d
{target} starts down the slope, but slips and slides down!

chase (down):4000:0:d
{target} steps onto the slope and begins to slide down uncontrollably!

chase (float):4000:0:drink levitation
{target} drinks a bubbling white potion, and begins to float upwards!

chase (hole):4000:0:go hole
{target} climbs down through the hole.

chase (hole):4000:0:go hole
{target} climbs into a hole.

chase (hole):4000:0:go hole
{target} climbs into the hole in the ceiling!

chase (hole):4000:0:go hole
{target} climbs into the small hole in the hillside.

chase (hole):4000:0:go hole
{target} climbs out of the small hole in the hillside!

chase (hole):4000:0:go hole
{target} climbs out through the hole to the south.

chase (hole):4000:0:go hole
{target} climbs out through the hole.

chase (hole):4000:0:go hole
{target} climbs through a hole in the wall!

chase (hole):4000:0:go hole
{target} climbs through the slimy hole.

chase (hole):4000:0:go hole
{target} crawls into the largest hole in the avalanche of stone.

chase (hole):4000:0:go hole
{target} pushes through the tentacles and into the hole.

chase (jump):4000:0:jump east
{target} steps back, starts running to the east, and makes a mighty leap!

chase (jump):4000:0:jump north
{target} steps back, starts running to the north, and makes a mighty leap!

chase (jump):4000:0:jump south
{target} steps back, starts running to the south, and makes a mighty leap!

chase (jump):4000:0:jump west
{target} steps back, starts running to the west, and makes a mighty leap!

chase (lake):4000:0:u
{target} climbs out of the water.

chase (lake):4000:0:d
{target} steps into the water at the lake's edge and dives beneath the ice!

chase (lever):4000:0:pull lever
{target} pulls the lever, and falls through a trapdoor!

chase (lever):4000:0:pull lever
{target} pulls the lever, and steps through the gate.

chase (manhole):4000:0:go manhole
{target} enters a manhole in the ground!

chase (manhole):4000:0:go manhole
{target} squeezes into the dark space beneath the manhole.

chase (moat):4000:0:u
{target} climbs out of the filthy moat.

chase (moat):4000:0:d
{target} dives into the black waters of the moat!

chase (moat):4000:0:go moat
{target} jumps into the filthy black waters of the moat.

chase (mountain stair):4000:0:d
{target} climbs down the mountain stair.

chase (mountain stair):4000:0:u
{target} climbs up the mountain stair.

chase (path):4000:0:go path
{target} follows a hidden path!

chase (path):4000:0:go path
{target} pushes through the bushes, and walks onto a concealed path.

chase (path):4000:0:go path
{target} shoves aside the foliage, and disappears among the trees.

chase (path):4000:0:go path
{target} steps onto the side-path and quickly vanishes from view.

chase (portal):4000:0:go crimson
{target} enters the crimson portal and vanishes!

chase (portal):4000:0:go ebony
{target} enters the ebony portal and vanishes!

chase (portal):4000:0:go golden
{target} enters the golden portal and vanishes!

chase (portal):4000:0:go portal
{target} steps into the dark portal, and vanishes!

chase (portal):4000:0:go portal
{target} steps into the portal, and disappears!

chase (portal):4000:0:go portal
{target} steps through the shimmering portal, and vanishes!

chase (portal):4000:0:go portal
{target} steps through the swirling portal.

chase (skiff):4000:0:s
{target} climbs into a boat, and rows off across the river.

chase (skiff):4000:0:go skiff
{target} climbs into one of the skiffs, and rows out into the river.

chase (skiff):4000:0:n
{target} hops into one of the boats, and begins to row out across the river.

chase (skiff):4000:0:n
{target} hops into one of the skiffs, and rows away.

chase (skiff):4000:0:n
{target} rows a skiff north, up to the shore.

chase (skiff):4000:0:s
{target} rows a skiff south, up to the Silvermere docks.

chase (skiff):4000:0:e
{target} rows a wooden skiff to the east.

chase (skiff):4000:0:n
{target} rows a wooden skiff to the north.

chase (skiff):4000:0:ne
{target} rows a wooden skiff to the northeast.

chase (skiff):4000:0:nw
{target} rows a wooden skiff to the northwest.

chase (skiff):4000:0:s
{target} rows a wooden skiff to the south.

chase (skiff):4000:0:se
{target} rows a wooden skiff to the southeast.

chase (skiff):4000:0:sw
{target} rows a wooden skiff to the southwest.

chase (skiff):4000:0:w
{target} rows a wooden skiff to the west.

chase (stone altar):4000:0:touch altar
{target} touches the hideous stone altar.

chase (tree):4000:0:climb tree
{target} carefully begins to climb down.

chase (tree):4000:0:climb tree
{target} grasps onto a branch of the tree, and climbs upwards.

chase (tree):4000:0:climb tree
{target} jumps and grabs onto a low branch, and begins to climb the tree.

chase (up):4000:0:u
{target} climbs the steps encircling the ancient silverwood tree.

chase (up):4000:0:u
{target} climbs up through the filthy pipe.

chase (vines):4000:0:climb vines
{target} swings over the edge of the cliff, and climbs down the vines!

chase (vortex):4000:0:go vortex
{target} steps into the swirling vortex, and vanishes in a flash!

chase (wall):4000:0:e
{target} walks through the wall to the east!

chase (wall):4000:0:w
{target} walks through the wall to the west!

chase (warehouse):4000:0:n
The chains snap, and {target} slips inside the warehouse.

chase (waterfall):4000:0:w
{target} walks through the waterfall!

chase (willow):4000:0:go willow
{target} gingerly steps inside the cracked willow.

cloak of faith:0000:0:
You feel the power of the gods touch your body!
The blessing fades away!
cloud of spores:0002:2:
You are plagued by horrible hallucinations
The awful hallucinations slowly die off
cold flame:0000:0:
{target} are seared by cold flame for {dmg} damage!

cold hits:0000:0:
{target} are chilled for {dmg} damage!

cold hits:0000:0:
{target} is chilled for {dmg} damage!

combat fury:0000:0:
You are consumed by a berserker fury
The berserker fury consuming you subsides
combust:0000:0:
{target} combust for {dmg} damage!

confusion:0002:2:
You are confused
The effects of confusion wear off
constriction:0010:0:
You are being constricted by a magical serpent
The serpent shrivels up and falls away
constriction:0012:2:
You are caught in a snakes coils.
The constrictor releases its grasp.
constriction:0012:2:
You are caught in the snakes coils.
The constrictor releases its grasp.
convulsions:2000:0:
You look around stupidly and do nothing!

convulsions:0002:0:
You are in convulsions!
Your body returns to normal.
corrosion:0000:0:
You feel vulnerable
You feel safer now
creature illusion:0002:0:
You are distracted by illusionary attackers
Without a sound: the illusionary attackers vanish
creeping doom:0008:0:
You are covered in deadly insects
The insects biting and stinging you die off
crimson bracers:0000:0:
A blazing inferno sears {target} for {dmg} damage!

cross of vengeance:0000:0:
You are surrounded by a brilliant light
The light from the Cross of Vengeance winks out
curse:0000:0:
You feel unlucky
The effects of curse wear off
curved black dagger:0000:0:
The dagger drains {target} of life for {dmg} damage!

damn:0000:0:
You are damned!
The malaise of your soul has lifted
dancing blades:0000:0:
Dancing blades slice the foe for {dmg} damage!

dark plague:0008:0:
A plague is consuming your flesh!
The plague has left your ravaged body
dark transfusion:0000:0:
You are filled with a feeling of grace.
The feeling subsides
darkbane:0000:0:
{target} is purified with divine power for {dmg} damage!

Darkbane:0000:0:
{target} is purified with divine power for {dmg} damage!

darkwood forest sounds:0000:0:^M
The leaves begin to rustle, as if some beast were about to spring forth!

death chicken:0000:1:
A deathly shriek announces an evil prescence!

deaths shadow:0000:0:
A small throwing knife hits {target} for {dmg} damage!

deaths shadow:0000:0:
You throw a small knife at {target} for {dmg} damage!

deathtouch:0000:0:
Dark energy drains {target} of life for {dmg} damage!

desert damage:0000:5:drink water
You suffer in the desert heat...

desert sounds:0000:0:^M
The howl of some awful beast can be heard far over the dunes.

disease:0008:0:
You are diseased
The disease dies down
divine courage:0000:0:
You feel very courageous!
You begin to feel less courageous.
divine disfavour:0000:0:
You feel EXTREMELY unlucky
The effects of divine disfavour wear off
divine favour:0000:0:
You feel EXTREMELY lucky
The effects of divine favour wear off
dragonblades:0000:0:
A blazing firestorm burns through {target} for {dmg} damage!

dragonclaw staff:0000:0:
Blue lightning streaks among your foes for {dmg} damage!

dragonclaw staff:0000:0:
Blue lightning streaks out and sears {target} for {dmg} damage!

dragonfire:0000:0:
A withering blast of dragonfire sears {target} for {dmg} damage!

eagle helm:0000:0:
Your eyes are tingling
Your awareness returns to normal
earthbind:0000:0:
Your energies are bound to the earth!
Your energies flow unbound
earthquake:0000:0:
An earthquake rocks {target} for {dmg} damage!

ebony kris:0000:0:
{target} take {dmg} damage from the venom!

ebony kris:0000:0:
{target} takes {dmg} damage from the venom!

elemental fury:0000:0:
Fire burns {target} for {dmg} damage!

elemental fury:0000:0:
Ice freezes {target} for {dmg} damage!

elemental fury:0000:0:
Lighting strikes {target} for {dmg} damage!

elemental fury:0000:0:
Lightning strikes {target} for {dmg} damage!

elemental fury:0000:0:
Shards of stone slice {target} for {dmg} damage!

embroidered black gauntlets:0000:0:
Dark energy sears {target} for {dmg} damage!

emerald-tipped crozier:0000:0:
You are protected by divine power
You feel vulnerable
engulf in flame:0008:0:
You are engulfed in flames
The flames enveloping you die down
engulfs:0010:0:
You are engulfed
You are freed
entangle:0010:0:
You are entangled
The effects of entangle wear off
entangle:0010:2:
Your feet are incased in coral!
You can move again!
ethereal shield:0000:0:
You feel protected
The effects of ethereal shield wear off
excorcism:0000:0:
A brilliant beam zaps {target} for {dmg} damage!

explosion:0000:0:
An explosion rocks {target} for {dmg} damage!

faithkeeper:0000:0:
You feel the gods power manifest within you!
The guidance fades!
fear:0010:0:
You are afraid
The effects of fear wear off
feeblemind:0000:0:
You feel moronic
You feel your intelligence return
fire shield:0000:0:
You feel resistant to fire
The effects of resist fire wear off
fire trap:0000:0:
A jet of flame blasts forth and scorches {target} for {dmg} damage!

fireball:0000:0:
{target} take {dmg} damage from the explosion!

flametongue:0000:0:
{target} take {dmg} fire damage!

flametongue:0000:0:
{target} takes {dmg} fire damage!

flay:0004:0:
flays you viciously
The effects of the poison wear off
flesh-eater:0000:0:
Your flesh dissolves, causing {target} {dmg} damage!

folds of worship:0200:0:
You feel at one with the gods!
Your spiritual link fades to normal!
folds of worship:0200:0:
You pull your cloak tight about you!
Your spiritual link fades to normal!
forest sounds:0000:1:
The forest becomes strangely silent.

forest sounds:0000:1:
A dry twig snaps loudly behind you.

forest sounds:0000:1:
A flock of birds fly overhead.

forest sounds:0000:1:
An ominous wind blows through the trees.

forest sounds:0000:1:
The leaves begin to rustle, as if some beast were about to spring forth!

forked lightning:0000:0:
Forked lightning streaks out and fries {target} for {dmg} damage!

form of the crane:0000:0:
The spirit of the crane inhabits your body!
The spirit of the crane has left your body!
form of the dragon:0080:0:
The spirit of the dragon inhabits your body!
The spirit of the dragon has left your body!
form of the gorilla:0000:0:
The spirit of the gorilla inhabits your body!
The spirit of the gorilla has left your body!
form of the monkey:0000:0:
The spirit of the monkey inhabits your body!
The spirit of the monkey has left your body!
form of the monkey:0000:0:
You are distracted!
The spirit of the monkey has left your body!
form of the viper:0000:0:
The spirit of the viper inhabits your body!
The spirit of the viper has left your body!
freeze:0010:0:
You are frozen to the ground
You become unfrozen
freezing blizzard:0008:0:
Icy hail pelts everyone in the room
Your awareness returns to normal.
freezing blizzard:0008:0:
Icy hail pelts {target}, freezing your bones!
Your awareness returns to normal.
freezing blizzard:0008:0:
You feel oblivious!
Your awareness returns to normal.
frenzy:0000:0:
You are in a battle frenzy
Your frenzied state wears off
frost hydra entry:0000:0:^M
The hydra strains against its icy bond, breaks it, and comes to life!

frost sceptre:0000:0:
A withering blast of cold freezes {target} for {dmg} damage!

frost sceptre-chill touch:0008:0:
You are chilled
The chill fades away
fumble:2002:2:
You fumble in confusion
The effects of confusion wear off
fungus cloud:0000:0:
Your lungs are filled with spores!
Your lungs fill with fresh air
galleon transport:0000:0:^M
You suddenly find your self aboard an ancient sea vessel!

gauntlets of power:0000:0:
You feel powerful
You feel less powerful
giant skeleton shriek:0000:0:
A storm of freezing hail smashes {target} for {dmg} damage!

glacial skin:0000:0:
Your skin is covered in hardened protective ice!
The protective ice melts and your skin returns to normal.
glass orb:0000:0:
You feel lucky!
The effects of bless wear off!
glitterdust:0000:0:
You are glittering
The glittering dust wears off
globe of darkness:0001:0:
You are enveloped in darkness
The unnatural darkness lifts
globe of the elements:0000:0:
A globe of the elements surrounds you!
The globe dissipates into nothing!
globule:0010:2:
You are held by the queen's spit
You can move again
gnarled wand:0000:0:
A bolt of white-hot flame strikes {target} for {dmg} damage!

gnarled wand:0000:0:
{source} points a gnarled wand at {target} and utters "Shirzak!"

gold dust:0000:0:
You are cursed by a leprechaun
The leprechaun's curse wears off
grall bite:0000:0:
Your energies have been dampened!
The dampening effect has gone!
granite orb:0000:0:
You feel powerful!
The effects of smite wear off!
greater bless:0000:0:
You feel VERY lucky
The effects of greater bless wear off
greater curse:0000:0:
You feel VERY unlucky
The effects of greater curse wear off
gruesome curse:0000:0:
You don't feel so good.
You begin to feel better, the taint removed.
hand of death:0008:0:
You are affected by hand of death
The effects of hand of death wear off
hellfire shield:0000:0:
You are surrounded by an aura of hellfire!
The flames die down into nothingness.
hell-flail:0000:0:
Dark flame sears {target} for {dmg} damage!

heros tabard:0000:0:
You feel protected!
The protective magic fades.
high-pitched scream:0002:2:
You feel confused
The effects of the death dog's shriek wears off
hold person:0010:0:
Your legs are paralyzed
You can move again
holy armour:0000:0:
You feel protected
The effects of holy armour wear off
holy aura:0000:0:
You feel safe from evil
The effects of protection from evil wear off
Holy Wrath and Righteous Fury:0000:0:
{target} is purified with divine power for {dmg} damage!

hot pants:0002:2:
You are mesmerized!
The effects of the hot pants wear off
hypnotic hands:0002:2:
You are confused
The effect of hypnotic hands wears off
ice crystal falchion:0000:0:
{target} take {dmg} damage from the cold!

ice crystal falchion:0000:0:
{target} takes {dmg} damage from the cold!

ice shield:0000:0:
You feel resistant to cold
The effects of resist cold wear off
ice storm:0008:0:
You are freezing
Your are no longer freezing
icehammer:0000:0:
{target} take {dmg} damage from the cold!

icehammer:0000:0:
{target} takes {dmg} damage from the cold!

infernal darkness:0001:0:
An unnatural darkness surrounds you!
The unnatural darkness dissipates
inferno:0000:0:
A pillar of flame appears and scorches {target} for {dmg} damage!

inquisitors cloak:0001:0:
You are blind!
You can see once more!
iron faith:0000:0:
Your resistance is strengthened
The effects of iron faith wear off
iron tube:0000:0:
A massive explosion blasts {target} for {dmg} damage!

iron tube:0000:0:
A massive explosion rocks {target} for {dmg} damage!

jade amulet:0004:0:
You are poisoned!
You rub your jade amulet!
jeweled viper death:0000:0:
Your blood runs cold as ice!
The chill leaves your body!
knockdown:0010:0:
You are flat on your back
You get back on your feet
leafwoven cloak:0200:0:
The energy of the earth flows through you!
The energies return to the land!
leprosy:0008:0:
You are covered in festering wounds
The festering wounds covering your body close abruptly
lightning hits:0000:0:
{target} are shocked for {dmg} damage!

lightning hits:0000:0:
{target} is shocked for {dmg} damage!

lightning shield:0000:0:
You feel resistant to lightning!
The effects of resist lightning wear off!
lightning trap:0000:0:
A bolt of lightning streaks out and fries {target} for {dmg} damage!

low on lives:0000:0:.LOW ON LIVES!^M=x
You feel your life-force ebbing.

maelstrom:0000:0:
A whirling maelstrom assaults {target} for {dmg} damage!

mageshield:0000:0:
You feel protected
Your mageshield shimmers and fades
magic armour:0000:0:
You feel armoured
The effects of magic armour wear off
magma blast:0000:0:
Your flaming magma blast strikes {target} for {dmg} damage!

magma blast:0000:0:
Your magma blast strikes {target} for {dmg} damage!

mana dead:0000:0:
Something has poisoned your mana!
Your mana returns to normal
mana flux:0200:0:
You are affected by a mana flux
The mana flux dissipates rapidly
mana storm:0000:0:
A swirling mana storm engulfs {target} for {dmg} damage!

manashield:0000:0:
You are surrounded by a shield of mana!
Your manashield dissolves into nothingness.
mantle of the woodsman:0000:0:
The feel of the hunt pulses in your veins!
The spirit of the hunt dissipates!
mass frenzy:0000:0:
You are in a battle frenzy
Your frenzied state wears off
mermex poison:0004:0:
You are dizzy and disoriented from poison
The dizzying poison runs its course
meteor swarm:0000:0:
Your streaking meteor swarm strikes {target} for {dmg} damage!

meteor swarm:0000:0:
{source} launches a meteor swarm at {target} for {dmg} damage!

mistweed:0004:0:
You are drowsy and disoriented!
You feel better.
mistweed:1034:0:
You are unconscious.
You awaken, groggy and confused from the poison.
molecular agitation:0000:0:
{target} are wracked with pain for {dmg} damage!

molecular agitation:0000:0:
{target} is wracked with pain for {dmg} damage!

monster entrance:0000:1:
From the fresh corpse arises a vampire!

monster entry:0000:1:
A barrow wight steps out of the shadows

monster entry:0000:1:
A chill runs down your spine. Something is with you!

monster entry:0000:1:
A coral lobster rises from its rest

monster entry:0000:1:
A dark storm approaches

monster entry:0000:1:
A deathly shriek announces an evil prescence

monster entry:0000:1:
A gibbering horror crawls out of the large gibbering horror's corpse

monster entry:0000:1:
A head sprouts from the hydra's shoulders

monster entry:0000:1:
A horde of severed heads descend upon you!

monster entry:0000:1:
A laughter filled with ancient evil sounds behind you

monster entry:0000:1:
A mocking female laugh announces an evil prescence

monster entry:0000:1:
A moss zombie rises from the ground

monster entry:0000:1:
A silvery skull materializes with a metallic shriek

monster entry:0000:1:
A skeleton arises from its place of rest

monster entry:0000:1:
A small gibbering horror crawls out of the gibbering horror's corpse

monster entry:0000:1:
A swirling red mist forms nearby

monster entry:0000:1:
A tentacled abomination slithers out of the dark pool

monster entry:0000:1:
A whipvine breaks through the ground

monster entry:0000:1:
An unholy idol animates

monster entry:0000:1:
As the Champion of Blood falls, a tower of fire whirls about his body

monster entry:0000:1:
Dark smoke and the smell of burning flesh flood the room

monster entry:0000:1:
Hundreds of insects rise from the ground forming a large swarm

monster entry:0000:1:
Out of nothingness a hundred scarab beetles appear to feast on you

monster entry:0000:1:
The dark phoenix hatches from its volcanic nest

monster entry:0000:1:
The feline form of a grall emerges from the shadows

monster entry:0000:1:
The giant shrugs off his glacial prison, and bellows in rage

monster entry:0000:1:
The hydra strains against its icy bond, breaks it, and comes to life!

monster entry:0000:1:
The king crab burrows up through the sand

monster entry:0000:1:
The storm giant king stands here in his throne room

moonblade:0000:0:
A brilliant beam zaps {target} for {dmg} damage!

multicoloured sash:0000:0:
You feel evasive
Your quickness returns to normal
mushroom poison:0004:0:
You feel deathly ill
The deathly sickness wears off
mute:0000:0:
You are silenced
You can talk again
natural prowess:0000:0:
Wild forces of nature enhance your prowess!
The forces of nature leave you.
nature tap:0200:0:
You feel the power of a nature tap!
Your tap into nature leaves your body!
net:0010:2:
You are entangled in a net!
You work yourself free again.
net end message:0000:0:stat
You work yourself free.

nexus spear:0000:0:
Energy sears {target} for {dmg} damage!

obsidian statue:0000:0:^M
The obisidan statue shatters into a thousand pieces.

obsidian statue death:0000:1:
The obisidan statue shatters into a thousand pieces.

opal ring:0000:0:
Dark energy sears {target} for {dmg} damage!

opalescent mist:0012:0:
Your mind is muddled
Your mind clears
orange potion:0000:0:
You feel heroic
Your heroism wears off
pale green lichen:0002:0:
You have an altered perception of reality
You shake your head dazedly as the effects of the lichen wear off
paralyze:0010:0:
Your legs are paralyzed
You can move again
paralyzed:0030:0:
You are paralyzed
The paralysis wears off
partial petrification:0000:0:
You are partially petrified
Your body returns to normal
peasant cloak:0200:0:
Your mind is at peace!
The chaos of the world returns!
petrification:1030:0:
You are transformed into stone
Your body returns to its normal state
petrification:1030:0:
You struggle, but you are solid stone
Your body returns to its normal state
plague:0008:0:
You are afflicted with a hideous plague
The hideous plague wears off
plague:0008:0:
You are plagued
The plague dies down
poison bolt:0004:0:
casts poison bolt upon you
The effects of the poison wear off
poison cloud:0004:0:
A noxious cloud of poison fills the room
The effects of the poison wear off
poison cloud:0004:0:
casts poison cloud on you
The effects of the poison wear off
poison hits:0000:0:
{target} are poisoned for {dmg} damage!

poison hits:0000:0:
{target} is poisoned for {dmg} damage!

pool:0080:0:
You feel weak, but tranquil and soothed
The weakness and feeling of tranquility wears off
powerless:0000:0:
You feel powerless
You suddenly feel your strength return
pressure points:0000:0:
You are using pressure points
You stop using pressure points
priestly benediction:0000:0:
You are filled with a feeling of grace
The feeling subsides
prismatic beam:0000:0:
A massive blast of light sears your foes for {dmg} damage!

profane link:0000:0:
A profane link is enhancing your power!
The link fades away into nothingness.
protection from evil:0000:0:
You feel safe from evil
You no longer feel safe from evil!
protection from good:0000:0:
You feel safe from good
The effects of protection from good wear off
protective shell:0000:0:
You are encompassed by a protective shell!
Your protective shell vanishes into nothing
pyramid doors:0000:0:^M
Doors on this level creak and thump!

Rakshasha:1000:0:
The illusion vanishes in a flash!

rapid healing:0080:0:
You are healing faster
Your healing rate returns to normal
regeneration:0080:0:
You are regenerating quickly
You stop regenerating
rejuvinating field:0000:0:
You are regenerating quickly!
You stop rgenerating.
resist cold:0000:0:
You feel resistant to cold
The effects of resist cold wear off
resist cold:0000:0:
You feel resistant to cold!
The effects of resist cold wear off!
resist fire:0000:0:
You feel resistant to fire
The effects of resist fire wear off
resist lightning:0000:0:
You feel resistant to lightning
The effects of resist lightning wear off
Retch:2000:0:
You retch uncontrollably!

righteousness:0000:0:
You are filled with divine power
The righteousness wears off
rip:0008:0:
You are bleeding all over the place
You stop bleeding
roar:0010:0:
You are too scared to flee
You feel braver
rosebush sleep:0000:0:st
You awaken from unnatural slumber.

rosewood rod:0080:0:
You are healing faster!
Your healing rate returns to normal.
rotting flesh:0008:0:
You are rotting
The disease dies down
runed cape:0200:0:
You see the magical runes auras around you!
The auras fade!
sacred bastion:0000:0:
You are surrounded in a silvery aura!
The silvery aura fades.
sand blind:0001:2:
You are blinded by the sand
You can see again
sandstorm:0001:2:
A sandstorm surrounds you!
The sandstorm subsides, allowing your scathed flesh to heal.
sawblade trap:0000:0:
A whirring sawblade swings out and rips {target} for {dmg} damage!

senselessness:0000:0:
You feel oblivious
Your awareness returns to normal
serenity:0000:0:
You feel calm and serene.
The feeling of serenity fades away.
serpent scourge:0000:0:
Venom sears {target} for {dmg} damage!

severd heads:0000:1:
A horde of severed heads descend upon you!

shadowform:0000:0:
You are a shadow
You return to your normal form
shapeshifter:1400:0:
and changes into an amorphous beast!

sharp blade:0008:0:
You are bleeding from a jagged, painful wound
The painful bleeding wound closes
shawl of fortune:0000:0:
The grace of the ancient gypsies flows through you!
The ancient gypsy grace leaves your body!
shimmering longsword:0000:0:
You feel lucky
The effects of bless wear off
shimmering mirage:0000:0:
You are fading in and out of view!
The shimmering glow fades away
shock hit:0000:0:
{target} is shocked for {dmg} damage!

shockshield:0000:0:
You are shockshielded
The effects of shockshield wear off
shockshield:0000:0:
You are surrounded by a shield of lightning!
The effects of shockshield wear off
shockshield:0000:0:
{target} are zapped for {dmg} damage!

Silveremere sounds:0000:0:^M
A dog barks off in the distance.

Silvermere sounds:0000:0:^M
A guardsman shouts out the time of day.

Silvermere sounds:0000:0:^M
A voice shouts aloud "Read the bulletin in the Adventurer's Guild!"

Silvermere sounds:0000:0:^M
Children rush past you hopping around in youthful glee.

Silvermere sounds:0000:0:^M
A cheer of many voices can be heard in the distance.

Silvermere sounds:0000:0:^M
The awful sound of a drunken chorus echoes through the streets.

silverwood staff:0000:0:
A brilliant beam of starlight spears {target} for {dmg} damage!

silvery mace:0000:0:
A shining spark strikes {target} for {dmg} damage!

skull-capped staff:0000:0:
A vampiric beam springs from the sockets and hits {target} for {dmg} damage!

sleep:0030:0:
You are fast asleep
You awaken from the unnatural slumber
sleep:0030:0:
You are lulled to sleep by the willow's magical song
You awaken from the unnatural slumber
slow:0000:0:
You feel slow
You speed up
smite:0000:0:
You feel powerful
The effects of smite wear off
solid fog:0000:0:
You feel slow
You speed up
song of agility:0000:0:
You feel agile
Your agility returns to normal
song of battle:0000:0:
Your blood races in your veins!
You begin to feel calmer.
song of beauty:0000:0:
You feel radiant!
Your charm returns to normal
song of brilliance:0000:0:
You feel smart
Your intelligence returns to normal
song of clumsiness:0000:0:
You feel clumsy
Your agility returns to normal
song of dazzling:0002:2:
You are confused
The effects of confusion wear off
song of deflection:0000:0:
You are protected from attack
Your shield of deflection wears off
song of draining:0000:0:
You sing the song of draining to {target}, draining {dmg} hit points!

song of draining:0000:0:
{source} sings the song of draining to {target}, draining dmg} hit points!

song of enlightenment:0000:0:
Your mind is enlightened!
The feeling of enlightenment passes
song of evasion:0000:0:
You are protected from attack!
Your evasiveness wears off.
song of foolishness:0000:0:
You feel foolish
Your wisdom returns to normal
song of force:0000:0:
You feel strong!
Your strength returns to normal.
song of heroism:0000:0:
You feel heroic
The feeling of heroism wears off
song of knowledge:0000:0:
You feel smart!
Your intelligence returns to normal.
song of lethargy:0000:0:
You feel slow
You speed up
song of life:0080:0:
You are healing faster
The song of life wears off
song of might:0000:0:
You feel strong
Your strength returns to normal
song of misfortune:0000:0:
You feel unlucky
The effects of misfortune wear off
song of quickness:0000:0:
You feel fast
You slow down
song of sageness:0000:0:
You feel wise!
Your wisdom returns to normal
song of shockwave:0000:0:
A shockwave strikes {target} for {dmg} damage!

song of silence:0000:0:
You are silenced
You can talk again
song of soothing:0080:0:
You feel soothed.
Your meditative state ends
song of stunning:0030:0:
You are stunned
You are no longer stunned
song of stupidity:0000:0:
You feel dull
Your intelligence returns to normal
song of swiftness:0000:0:
You feel agile!
Your agility returns to normal.
song of the elements:0000:0:
You feel protected from the elements.
You are no longer protected from the elements!
song of traveling:0000:0:
Your load is lightened
The effects of song of traveling wear off
song of valour:0000:0:
You feel confident
The effects of valour wear off
song of weakness:0000:0:
You feel weak!
Your strength returns to normal
song of wisdom:0000:0:
You feel wise
Your wisdom returns to normal
soul rip:0000:0:
A strange force rips into thin depraved murderer for 413 damage!

soul rip:0000:0:
A strange force rips into {target} for {dmg} damage!

soulstrike:0000:0:
Spiritual power strikes {target} for {dmg} damage!

sounds:0000:0:^M
Something sinister seems to tickle your senses.

speaks in a booming voice:0000:0:
You feel cursed
The effects of the mummy's curse wears off
spear trap:0000:0:
A spear flies out of the door and impales {target} for {dmg} damage!

speed:0000:0:
You feel fast
You slow down
spirit horde:0000:0:
A horde of shrieking spirits ravages {target} for {dmg} damage!

spits:0004:0:
You feel dizzy and weak
You are no longer dizzy and weak
spits a stream of venom:0004:0:
spits a stream of venom at you
The effects of the poison wear off
staff of the elements:0000:0:
An earthquake rocks {target} for {dmg} damage!

starlight:0000:0:
You are surrounded by a shimmering light!
Your starlight spell fades away.
Statue death:0000:1:
The obisidan statue shatters into a thousand pieces

stinking cloud:0000:0:
You feel nauseous
You feel less sick
stoneskin:0000:0:
Your skin is as hard as stone
Your skin returns to normal
storm crown:0000:0:
Forked lightning streaks out and fries {target} for {dmg} damage!

stormhammer:0000:0:
Lightning strikes {target} for {dmg} damage!

stormmetal bracers:0000:0:
White lightning shoots out frying {target} for {dmg} damage!

stunned:1030:0:
You are stunned
You are no longer stunned
sunsword:0000:0:
{target} are scorched for {dmg} damage!

sunsword:0000:0:
{target} is scorched for {dmg} damage!

swamp damage:0000:5:
You take {dmg} from the poisonous swamp

tails of battle:0000:0:
The dance of battle fills your mind!
The battle song fades!
telekinesis:0000:0:
{target} are picked up by a mysterious force and slammed down for {dmg} damage

telekinesis:0000:0:
{target} is picked up by a mysterious force and slammed down for {dmg} damage!

teleport:0004:0:
You are afflicted by teleportation sickness
The teleportation sickness wears off
tempest:0000:0:
The wind and rain batter {target} for {dmg} damage!

temple sounds:0000:0:^M
The angelic sound of a choir floats down through the air.

temple sounds:0000:0:^M
The large temple bell clangs loudly, echoing the time of day.

terror:0022:0:
You are afraid
The effects of fear wear off
terror:0022:0:
You have gone mad!
The effects of the madness wear off!
thick webbing:0010:0:
You are trapped in webbing
You are freed from the webbing
thin tendrils:0010:0:
You are bound by sticky threads
The organic cords binding you dissolve
thunderclap:0000:0:
A massive thunderclap blast your foes for {dmg} damage!

thunderclap:0000:0:
A massive thunderclap blasts {target} for {dmg} damage!

thunderstaff:0000:0:
Blue-white lightning strikes {target} for {dmg} damage!

thunderstaff:0000:0:
{target} takes {dmg} lightning damage!

time distortion:0000:0:
You are caught in a time distortion field
You speed up
trap disarm:2000:0:
An arrow shoots out of the wall and strikes you!

trap disarm:2000:0:
As you fiddle with the wire, large stones pound down on you from above!

trap disarm:2000:0:
Spikes jut out and stab you as you trigger the trap!

trap disarm:2000:0:
Spikes jut out and stab you!

trap disarm:2000:0:
You attempt to disarm the trap, and a huge stone block crushes you!

trap disarm:2000:0:
You fail to disarm the hidden release, and spikes stab into you!

trap disarm:2000:0:
You fail to disarm the trap, and blades sweep out and slice you!

trap disarm:2000:0:
You trigger the trap, and a large spear shoots out!

trap disarm:2000:0:
You trigger the trap, and two stone slabs spring out and crush you!

trap disarm:2000:0:
You try and disarm the trap, but trigger it!

trap disarm:2000:0:
You try to disarm the trap, but instead trigger it!

twisted bone staff:0000:0:
{target} life is drained for {dmg} damage!

twisted bone staff:0000:0:
{target}'s life is drained for {dmg} damage!

unholy armour:0000:0:
You feel protected
The effects of unholy armour wear off
unholy aura:0000:0:
You feel safe from good
The effects of protection from good wear off
unholy fanaticism:0000:0:
You are in a state of fanatical fury!
You feel yourself becoming calmer.
vile oil:0000:0:
You are nauseated
You recover from being nauseated
violet fluid:0009:0:
You are covered in a burning violet fluid!
The violet fluid covering you dries up.
voodoo stab:0000:0:
{target} feel a stabbing pain for {dmg} damage!

vortex of pain:0008:0:
You are in agony
The intense pain fades away
vulnerability:0000:0:
You feel vulnerable
You feel safer now
way of the bear:0000:0:
You feel strong, but clumsy
The way of the bear wears off
way of the boar:0000:0:
You feel berserk
The effects of way of the boar wear off
way of the cat:0000:0:
You feel stealthy
The effects of way of the cat wear off
way of the cobra:0004:0:
You are poisoned
The effects of the poison wear off
way of the mantis:0000:0:
You feel fast
You slow down
way of the monkey:0000:0:
You feel evasive
The effects of way of the monkey wear off
way of the owl:0000:0:
You feel strong-willed
The effects of way of the owl wear off
way of the rat:0000:0:
You are immune to poison
The way of the rat wears off
way of the tiger:0000:0:
You feel ferocious
The effects of way of the tiger wear off
way of the tortoise:0000:0:
You feel tough
The way of the tortoise wears off
way of the troll:0080:0:
You are regenerating quickly
You stop regenerating
weakness:0010:2:
You feel weak and powerless
You feel your strength return
web:0013:2:
You are caught in a cocoon!
You break free of the cocoon
whip entangle:0000:0:
You are pulled off-balance
You regain your balance
whirlwind of fire:0000:0:
A whirlwind of fire burns {target} for {dmg} damage!

white potion:0002:0:
You are drugged
Your body returns to normal
Winch failed:2000:0:
You heave mightily on the winch, but it does not budge.

wind of haste:0000:0:
You feel fast
You slow down
wing cut:0008:0:
You bleed from a deep gash!
You stop bleeding.
wretched boils:0008:0:
Boils fester all over your body!
The boils vanish from your body
Your spell has no effect in th:0000:1:^M
Your spell has no effect in this room!

zaps:0030:2:
You are stunned by electrical shock
The shock wears off
zeal:0000:0:
You are filled with divine power!
The righteousness wears off.
