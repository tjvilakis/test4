<legal stuff>
This is a free capture colorizer program for personal use, You take full 
responsibility for what you do with it or what it does to your system. 
</end legal stuff>
Have fun with it and let me know how it works or doesn't work so i can make it better.

You'll probably have to update the data.txt or your KCHdata.txt it's a simple format 
but don't change the order of the sections or you'll have problems. 
Put each entry on a new line.
** is to start a comment line these are ignored.

Remember not to unzip onto your kchdata.txt file either.

Use:
1. Make sure to add your party and monsters your fighting to the KCHdata.txt file.
	(This is your's to update i won't be doing it. If you have problems try putting 
	the kchdata.txt in a different directory something may be wrong with it.)
2. convert to html and view in browser, verify gray lines are what they should be or
3. edit KCHdata file for missing info and reconvert original cap.
	(see data.txt for examples)
4. The extension .mfc stands for MudForum Capture. You can open this with notepad or edit button.

Edit..
This opens any text file with notepad.

Thanks
D'Artagnan

Bugs:
Please sent the .cap or .txt file to my email if you have real problem. 
Anything over 100k that isn't a .txt or .cap will be deleted immediately and not read.
knotknownof@hotmail.com

Credits and general thanks for all the help.
Blood Fetish
Turbofoot
Sentinal
Cyan
Dameon
Hellspawn
Kefka
jbcc